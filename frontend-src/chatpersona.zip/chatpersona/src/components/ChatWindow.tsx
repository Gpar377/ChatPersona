'use client'

import { useEffect, useRef } from 'react'
import { Message } from '@/types'
import MessageBubble, { TypingIndicator } from './MessageBubble'

interface ChatWindowProps {
  messages: Message[]
  isTyping: boolean
}

function shouldShowTimestamp(messages: Message[], index: number): boolean {
  if (index === messages.length - 1) return true
  const current = messages[index]
  const next = messages[index + 1]
  const diff = next.timestamp.getTime() - current.timestamp.getTime()
  return diff > 1000 * 60 * 5 // show if 5+ mins apart
}

export default function ChatWindow({ messages, isTyping }: ChatWindowProps) {
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isTyping])

  // Group messages for visual spacing
  const getGrouping = (index: number) => {
    const prev = index > 0 ? messages[index - 1] : null
    const curr = messages[index]
    const isFirstInGroup = !prev || prev.role !== curr.role
    return isFirstInGroup
  }

  return (
    <div className="flex-1 overflow-y-auto px-4 md:px-8 py-6 space-y-1.5"
      style={{
        scrollbarWidth: 'thin',
        scrollbarColor: 'rgba(255,255,255,0.05) transparent',
      }}
    >
      {/* Memory header */}
      <div className="flex justify-center mb-6">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full"
          style={{
            background: 'rgba(255,255,255,0.03)',
            border: '1px solid rgba(255,255,255,0.06)',
          }}>
          <svg className="w-3 h-3 text-sage-400/70" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m3.75 2.383a14.406 14.406 0 01-3 0M14.25 18v-.192c0-.983.658-1.823 1.508-2.316a7.5 7.5 0 10-7.517 0c.85.493 1.509 1.333 1.509 2.316V18" />
          </svg>
          <span className="text-[11px] text-white/30 tracking-wide">Memory active · 847 messages learned</span>
        </div>
      </div>

      {messages.map((message, index) => (
        <div key={message.id} className={getGrouping(index) ? 'mt-4' : ''}>
          <MessageBubble
            message={message}
            showTimestamp={shouldShowTimestamp(messages, index)}
          />
        </div>
      ))}

      {isTyping && (
        <div className="mt-4">
          <TypingIndicator />
        </div>
      )}

      <div ref={bottomRef} />
    </div>
  )
}
