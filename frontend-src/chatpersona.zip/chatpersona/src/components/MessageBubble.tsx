'use client'

import { Message } from '@/types'

interface MessageBubbleProps {
  message: Message
  showTimestamp?: boolean
}

function formatTime(date: Date): string {
  return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true })
}

export default function MessageBubble({ message, showTimestamp }: MessageBubbleProps) {
  const isUser = message.role === 'user'

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} animate-fade-up`}>
      <div className={`max-w-[75%] md:max-w-[60%] ${isUser ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
        {/* Bubble */}
        <div className={`
          relative px-4 py-2.5 rounded-2xl
          ${isUser
            ? 'rounded-tr-sm text-white'
            : 'rounded-tl-sm text-white/85'
          }
        `}
          style={isUser
            ? {
              background: 'linear-gradient(135deg, #4a8a52 0%, #3d7a45 60%, #2d6535 100%)',
              boxShadow: '0 4px 20px rgba(74,138,82,0.3), 0 1px 0 rgba(255,255,255,0.08) inset',
            }
            : {
              background: 'rgba(255,255,255,0.05)',
              border: '1px solid rgba(255,255,255,0.07)',
              boxShadow: '0 4px 24px rgba(0,0,0,0.3), 0 1px 0 rgba(255,255,255,0.04) inset',
              backdropFilter: 'blur(12px)',
            }
          }
        >
          <p className="text-[13.5px] leading-relaxed tracking-[0.01em]">
            {message.content}
          </p>

          {/* Subtle corner detail */}
          {!isUser && (
            <div className="absolute top-0 left-0 w-2 h-2 overflow-hidden">
              <div className="absolute -top-1 -left-1 w-3 h-3 rounded-full border border-white/07" />
            </div>
          )}
        </div>

        {/* Timestamp */}
        {showTimestamp && (
          <span className={`text-[10px] text-white/20 px-1 ${isUser ? 'text-right' : 'text-left'}`}>
            {formatTime(message.timestamp)}
          </span>
        )}
      </div>
    </div>
  )
}

export function TypingIndicator() {
  return (
    <div className="flex justify-start animate-fade-in">
      <div
        className="px-4 py-3 rounded-2xl rounded-tl-sm"
        style={{
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid rgba(255,255,255,0.07)',
          backdropFilter: 'blur(12px)',
        }}
      >
        <div className="flex items-center gap-1 h-4">
          {[0, 1, 2].map(i => (
            <div
              key={i}
              className="w-1.5 h-1.5 rounded-full bg-white/40 animate-typing-dot"
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </div>
      </div>
    </div>
  )
}
