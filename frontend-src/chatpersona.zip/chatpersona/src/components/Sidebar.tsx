'use client'

import { useState } from 'react'
import { Persona, UploadState } from '@/types'
import { mockPersonas } from '@/data/mockData'
import FileUpload from './FileUpload'
import { useFileUpload } from '@/hooks/useFileUpload'

interface SidebarProps {
  currentPersonaId: string
  onSelectPersona: (id: string) => void
}

export default function Sidebar({ currentPersonaId, onSelectPersona }: SidebarProps) {
  const [isMobileOpen, setIsMobileOpen] = useState(false)
  const fileUpload = useFileUpload()

  return (
    <>
      {/* Mobile toggle */}
      <button
        className="fixed top-4 left-4 z-50 md:hidden w-9 h-9 rounded-xl bg-navy-800 border border-white/10 flex items-center justify-center text-white/60 hover:text-white transition-colors"
        onClick={() => setIsMobileOpen(!isMobileOpen)}
      >
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
        </svg>
      </button>

      {/* Overlay */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-30 md:hidden backdrop-blur-sm"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed md:relative z-40 h-full w-72 flex-shrink-0
        flex flex-col overflow-hidden
        bg-navy-900/95 border-r border-white/[0.06]
        transition-transform duration-300 ease-out
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}
        style={{ backdropFilter: 'blur(20px)' }}
      >
        {/* Ambient glow top */}
        <div className="absolute top-0 left-0 right-0 h-48 pointer-events-none"
          style={{ background: 'radial-gradient(ellipse at 50% -10%, rgba(90,158,98,0.12) 0, transparent 70%)' }} />

        {/* Logo section */}
        <div className="relative px-5 pt-7 pb-5">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #4a8a52, #3d7a45)' }}>
              <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 01-.825-.242m9.345-8.334a2.126 2.126 0 00-.476-.095 48.64 48.64 0 00-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0011.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155" />
              </svg>
            </div>
            <div>
              <h1 className="text-white font-semibold text-sm tracking-tight font-display">ChatPersona</h1>
            </div>
          </div>
          <p className="mt-2 ml-[42px] text-[11px] text-white/30 tracking-wide italic">
            Talk to your memories
          </p>
        </div>

        <div className="h-px bg-white/[0.05] mx-5" />

        {/* Upload section */}
        <div className="px-4 py-4">
          <p className="text-[10px] font-semibold text-white/25 uppercase tracking-widest mb-2.5 px-1">
            Upload Chat
          </p>
          <FileUpload
            uploadState={fileUpload.uploadState}
            uploadedFileName={fileUpload.uploadedFileName}
            isDragging={fileUpload.isDragging}
            onDrop={fileUpload.handleDrop}
            onDragOver={fileUpload.handleDragOver}
            onDragLeave={fileUpload.handleDragLeave}
            onInputChange={fileUpload.handleInputChange}
            onReset={fileUpload.reset}
          />
        </div>

        <div className="h-px bg-white/[0.05] mx-5" />

        {/* Personas list */}
        <div className="flex-1 overflow-y-auto px-3 py-4 scrollbar-thin">
          <p className="text-[10px] font-semibold text-white/25 uppercase tracking-widest mb-2.5 px-2">
            Personas
          </p>
          <div className="space-y-0.5">
            {mockPersonas.map(persona => (
              <PersonaItem
                key={persona.id}
                persona={persona}
                isActive={currentPersonaId === persona.id}
                onClick={() => { onSelectPersona(persona.id); setIsMobileOpen(false) }}
              />
            ))}
          </div>
        </div>

        {/* New Persona button */}
        <div className="p-4">
          <button className="
            w-full py-2.5 px-4 rounded-xl
            border border-white/[0.08] 
            flex items-center justify-center gap-2
            text-white/40 hover:text-white/70
            hover:border-white/15 hover:bg-white/[0.03]
            transition-all duration-200 group
            text-sm
          ">
            <svg className="w-4 h-4 transition-transform duration-200 group-hover:rotate-90" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            New Persona
          </button>
        </div>
      </aside>
    </>
  )
}

function PersonaItem({ persona, isActive, onClick }: {
  persona: Persona
  isActive: boolean
  onClick: () => void
}) {
  const colors = {
    R: 'from-blue-600 to-blue-700',
    P: 'from-purple-600 to-purple-700',
    A: 'from-amber-600 to-amber-700',
    M: 'from-rose-600 to-rose-700',
  }
  const colorKey = persona.avatar as keyof typeof colors

  return (
    <button
      onClick={onClick}
      className={`
        w-full flex items-center gap-3 px-3 py-2.5 rounded-xl
        transition-all duration-200 text-left group
        ${isActive
          ? 'bg-white/[0.07] border border-white/[0.08]'
          : 'hover:bg-white/[0.04] border border-transparent'
        }
      `}
    >
      {/* Avatar */}
      <div className={`
        relative flex-shrink-0 w-9 h-9 rounded-full bg-gradient-to-br ${colors[colorKey] || 'from-slate-600 to-slate-700'}
        flex items-center justify-center text-white text-xs font-semibold
      `}>
        {persona.avatar}
        {isActive && (
          <div className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-sage-500 rounded-full border-2 border-navy-900" />
        )}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <span className={`text-xs font-semibold ${isActive ? 'text-white' : 'text-white/70 group-hover:text-white/90'}`}>
            {persona.name}
          </span>
          <span className="text-[10px] text-white/25">{persona.lastMessageTime}</span>
        </div>
        <p className="text-[11px] text-white/30 truncate mt-0.5">{persona.lastMessage}</p>
      </div>
    </button>
  )
}
