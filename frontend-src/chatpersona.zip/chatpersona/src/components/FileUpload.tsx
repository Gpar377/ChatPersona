'use client'

import { useRef } from 'react'
import { UploadState } from '@/types'

interface FileUploadProps {
  uploadState: UploadState
  uploadedFileName: string | null
  isDragging: boolean
  onDrop: (e: React.DragEvent) => void
  onDragOver: (e: React.DragEvent) => void
  onDragLeave: () => void
  onInputChange: (e: React.ChangeEvent<HTMLInputElement>) => void
  onReset: () => void
}

export default function FileUpload({
  uploadState,
  uploadedFileName,
  isDragging,
  onDrop,
  onDragOver,
  onDragLeave,
  onInputChange,
  onReset,
}: FileUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null)

  const stateContent = {
    idle: {
      icon: (
        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5m-13.5-9L12 3m0 0l4.5 4.5M12 3v13.5" />
        </svg>
      ),
      text: 'Drop a WhatsApp export',
      sub: '.txt files only',
      color: isDragging ? 'border-sage-500 bg-sage-500/10' : 'border-white/10 hover:border-white/20',
    },
    uploading: {
      icon: (
        <div className="w-6 h-6 border-2 border-sage-400/40 border-t-sage-400 rounded-full animate-spin" />
      ),
      text: 'Reading chat…',
      sub: uploadedFileName || '',
      color: 'border-sage-500/40',
    },
    processing: {
      icon: (
        <div className="flex gap-1 items-center">
          {[0, 1, 2].map(i => (
            <div
              key={i}
              className="w-1.5 h-1.5 bg-sage-400 rounded-full animate-typing-dot"
              style={{ animationDelay: `${i * 0.15}s` }}
            />
          ))}
        </div>
      ),
      text: 'Processing memory…',
      sub: 'Building personality model',
      color: 'border-sage-500/40',
    },
    done: {
      icon: (
        <svg className="w-6 h-6 text-sage-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      ),
      text: 'Memory loaded',
      sub: uploadedFileName || '',
      color: 'border-sage-500/30 bg-sage-500/5',
    },
  }

  const current = stateContent[uploadState]

  return (
    <div
      className={`relative rounded-xl border border-dashed p-4 transition-all duration-300 cursor-pointer group ${current.color}`}
      onDrop={uploadState === 'idle' ? onDrop : undefined}
      onDragOver={uploadState === 'idle' ? onDragOver : undefined}
      onDragLeave={uploadState === 'idle' ? onDragLeave : undefined}
      onClick={() => uploadState === 'idle' && inputRef.current?.click()}
    >
      <input
        ref={inputRef}
        type="file"
        accept=".txt"
        className="hidden"
        onChange={onInputChange}
      />

      <div className="flex items-center gap-3">
        <div className={`text-white/40 transition-colors duration-200 ${uploadState === 'idle' ? 'group-hover:text-sage-400' : uploadState === 'done' ? '' : 'text-sage-400'}`}>
          {current.icon}
        </div>
        <div className="flex-1 min-w-0">
          <p className={`text-xs font-medium truncate transition-colors ${uploadState === 'done' ? 'text-sage-400' : 'text-white/60'}`}>
            {current.text}
          </p>
          {current.sub && (
            <p className="text-[10px] text-white/30 truncate mt-0.5">{current.sub}</p>
          )}
        </div>
        {uploadState === 'done' && (
          <button
            onClick={(e) => { e.stopPropagation(); onReset() }}
            className="text-white/20 hover:text-white/50 transition-colors p-1"
          >
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>

      {/* Progress bar for uploading/processing */}
      {(uploadState === 'uploading' || uploadState === 'processing') && (
        <div className="mt-3 h-px bg-white/5 rounded-full overflow-hidden">
          <div
            className={`h-full bg-sage-500/60 rounded-full transition-all duration-1000 ${uploadState === 'processing' ? 'w-3/4' : 'w-1/3'}`}
          />
        </div>
      )}
    </div>
  )
}
