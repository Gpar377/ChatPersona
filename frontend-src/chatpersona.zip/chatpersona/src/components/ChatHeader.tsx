'use client'

import { Persona } from '@/types'

interface ChatHeaderProps {
  persona: Persona
  isTyping: boolean
}

const avatarColors: Record<string, string> = {
  R: 'from-blue-600 to-blue-700',
  P: 'from-purple-600 to-purple-700',
  A: 'from-amber-600 to-amber-700',
  M: 'from-rose-600 to-rose-700',
}

export default function ChatHeader({ persona, isTyping }: ChatHeaderProps) {
  return (
    <div className="
      relative flex items-center gap-3.5 px-6 py-4
      border-b border-white/[0.06]
      bg-navy-900/80
    " style={{ backdropFilter: 'blur(20px)' }}>

      {/* Subtle top line accent */}
      <div className="absolute top-0 left-0 right-0 h-px"
        style={{ background: 'linear-gradient(90deg, transparent, rgba(90,158,98,0.3), transparent)' }} />

      {/* Avatar */}
      <div className="relative flex-shrink-0">
        <div className={`
          w-10 h-10 rounded-full bg-gradient-to-br ${avatarColors[persona.avatar] || 'from-slate-600 to-slate-700'}
          flex items-center justify-center text-white text-sm font-semibold
          ring-2 ring-white/5
        `}>
          {persona.avatar}
        </div>
        <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-sage-500 rounded-full border-2 border-navy-900 animate-pulse-soft" />
      </div>

      {/* Name + status */}
      <div>
        <h2 className="text-white font-semibold text-sm leading-tight">
          {persona.name}
        </h2>
        <div className="flex items-center gap-1.5 mt-0.5">
          {isTyping ? (
            <span className="text-[11px] text-sage-400 flex items-center gap-1">
              <span>typing</span>
              <span className="flex gap-0.5">
                {[0, 1, 2].map(i => (
                  <span
                    key={i}
                    className="inline-block w-1 h-1 bg-sage-400 rounded-full animate-typing-dot"
                    style={{ animationDelay: `${i * 0.15}s` }}
                  />
                ))}
              </span>
            </span>
          ) : (
            <span className="text-[11px] text-white/30">Based on your chat history · {persona.relationship}</span>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="ml-auto flex items-center gap-2">
        <button className="w-8 h-8 rounded-xl flex items-center justify-center text-white/30 hover:text-white/60 hover:bg-white/[0.05] transition-all duration-150">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
          </svg>
        </button>
        <button className="w-8 h-8 rounded-xl flex items-center justify-center text-white/30 hover:text-white/60 hover:bg-white/[0.05] transition-all duration-150">
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM12.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0zM18.75 12a.75.75 0 11-1.5 0 .75.75 0 011.5 0z" />
          </svg>
        </button>
      </div>
    </div>
  )
}
