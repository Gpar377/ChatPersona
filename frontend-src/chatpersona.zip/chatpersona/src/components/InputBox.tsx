'use client'

import { useRef, useEffect, KeyboardEvent } from 'react'

interface InputBoxProps {
  value: string
  onChange: (v: string) => void
  onSend: (text: string) => void
  isTyping: boolean
  disabled?: boolean
}

export default function InputBox({ value, onChange, onSend, isTyping, disabled }: InputBoxProps) {
  const inputRef = useRef<HTMLTextAreaElement>(null)

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleSend = () => {
    if (!value.trim() || isTyping) return
    onSend(value)
  }

  // Auto-resize textarea
  useEffect(() => {
    const el = inputRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = Math.min(el.scrollHeight, 120) + 'px'
  }, [value])

  const canSend = value.trim().length > 0 && !isTyping

  return (
    <div className="px-4 md:px-8 py-4 border-t border-white/[0.05]"
      style={{ background: 'rgba(7,13,26,0.8)', backdropFilter: 'blur(20px)' }}>
      <div className="
        relative flex items-end gap-3
        rounded-2xl px-4 py-3
        transition-all duration-200
      "
        style={{
          background: 'rgba(255,255,255,0.04)',
          border: '1px solid rgba(255,255,255,0.08)',
          boxShadow: '0 0 0 0 rgba(90,158,98,0)',
        }}
        onFocus={() => { }}
      >
        {/* Emoji button */}
        <button className="flex-shrink-0 mb-0.5 text-white/25 hover:text-white/50 transition-colors duration-150">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.182 15.182a4.5 4.5 0 01-6.364 0M21 12a9 9 0 11-18 0 9 9 0 0118 0zM9.75 9.75c0 .414-.168.75-.375.75S9 10.164 9 9.75 9.168 9 9.375 9s.375.336.375.75zm-.375 0h.008v.015h-.008V9.75zm5.625 0c0 .414-.168.75-.375.75s-.375-.336-.375-.75.168-.75.375-.75.375.336.375.75zm-.375 0h.008v.015h-.008V9.75z" />
          </svg>
        </button>

        {/* Input */}
        <textarea
          ref={inputRef}
          value={value}
          onChange={e => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={isTyping ? '' : "Say something…"}
          rows={1}
          disabled={disabled}
          className="
            flex-1 bg-transparent resize-none outline-none
            text-white/80 placeholder-white/20
            text-[13.5px] leading-relaxed
            disabled:opacity-50
          "
          style={{ maxHeight: '120px', scrollbarWidth: 'none' }}
        />

        {/* Attach button */}
        <button className="flex-shrink-0 mb-0.5 text-white/25 hover:text-white/50 transition-colors duration-150">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M18.375 12.739l-7.693 7.693a4.5 4.5 0 01-6.364-6.364l10.94-10.94A3 3 0 1119.5 7.372L8.552 18.32m.009-.01l-.01.01m5.699-9.941l-7.81 7.81a1.5 1.5 0 002.112 2.13" />
          </svg>
        </button>

        {/* Send button */}
        <button
          onClick={handleSend}
          disabled={!canSend}
          className={`
            flex-shrink-0 mb-0.5 w-8 h-8 rounded-xl
            flex items-center justify-center
            transition-all duration-200
            ${canSend
              ? 'text-white hover:-translate-y-0.5 hover:shadow-glow-sage active:translate-y-0 active:scale-95'
              : 'text-white/20 cursor-not-allowed'
            }
          `}
          style={canSend ? {
            background: 'linear-gradient(135deg, #4a8a52, #3d7a45)',
            boxShadow: '0 4px 16px rgba(74,138,82,0.35)',
          } : {
            background: 'rgba(255,255,255,0.04)',
          }}
        >
          <svg className="w-4 h-4 rotate-90" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
          </svg>
        </button>
      </div>

      <p className="text-center text-[10px] text-white/15 mt-2">
        Press Enter to send · Shift+Enter for new line
      </p>
    </div>
  )
}
