'use client'

import { useState, useCallback } from 'react'
import { UploadState } from '@/types'

export function useFileUpload() {
  const [uploadState, setUploadState] = useState<UploadState>('idle')
  const [uploadedFileName, setUploadedFileName] = useState<string | null>(null)
  const [isDragging, setIsDragging] = useState(false)

  const handleFile = useCallback(async (file: File) => {
    if (!file.name.endsWith('.txt')) return

    setUploadedFileName(file.name)
    setUploadState('uploading')

    await new Promise(r => setTimeout(r, 900))
    setUploadState('processing')

    await new Promise(r => setTimeout(r, 1800))
    setUploadState('done')
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) handleFile(file)
  }, [handleFile])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback(() => {
    setIsDragging(false)
  }, [])

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleFile(file)
  }, [handleFile])

  const reset = useCallback(() => {
    setUploadState('idle')
    setUploadedFileName(null)
  }, [])

  return {
    uploadState,
    uploadedFileName,
    isDragging,
    handleDrop,
    handleDragOver,
    handleDragLeave,
    handleInputChange,
    reset,
  }
}
