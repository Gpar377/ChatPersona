'use client'

import { useState, useCallback } from 'react'
import { Message } from '@/types'
import { mockMessages } from '@/data/mockData'

const aiReplies = [
  "You know what's funny? I was just thinking about that the other day.",
  "Okay but that memory is so specific, only you would remember that detail 😂",
  "I think that was one of those moments that just sticks. You know what I mean?",
  "Man, time really does something weird to memories. Some things feel like yesterday.",
  "That reminds me of the time you completely overreacted about something totally small 😄 but in the best way.",
  "I don't know. I think we were just figuring it out, same as everyone else. We just had each other to be weird with.",
  "Honestly? That was one of the good ones. Not everything was — but that was.",
  "You always had this way of making everything feel like an adventure even when it was just a Tuesday.",
]

let replyIndex = 0

export function useChat() {
  const [messages, setMessages] = useState<Message[]>(mockMessages)
  const [inputText, setInputText] = useState('')
  const [isTyping, setIsTyping] = useState(false)

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text.trim(),
      timestamp: new Date(),
    }

    setMessages(prev => [...prev, userMessage])
    setInputText('')
    setIsTyping(true)

    // Simulate AI thinking
    const delay = 1200 + Math.random() * 1200

    await new Promise(resolve => setTimeout(resolve, delay))

    const aiMessage: Message = {
      id: (Date.now() + 1).toString(),
      role: 'ai',
      content: aiReplies[replyIndex % aiReplies.length],
      timestamp: new Date(),
    }

    replyIndex++
    setIsTyping(false)
    setMessages(prev => [...prev, aiMessage])
  }, [])

  return {
    messages,
    inputText,
    setInputText,
    isTyping,
    sendMessage,
  }
}
