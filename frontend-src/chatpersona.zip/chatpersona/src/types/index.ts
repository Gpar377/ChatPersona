export interface Message {
  id: string
  role: 'user' | 'ai'
  content: string
  timestamp: Date
}

export interface Persona {
  id: string
  name: string
  avatar: string
  lastMessage: string
  lastMessageTime: string
  unread?: number
  relationship: string
}

export type UploadState = 'idle' | 'uploading' | 'processing' | 'done'
