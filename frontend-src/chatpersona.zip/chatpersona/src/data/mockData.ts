import { Message, Persona } from '@/types'

export const mockPersonas: Persona[] = [
  {
    id: '1',
    name: 'Rahul',
    avatar: 'R',
    lastMessage: "How could I forget? You almost lost your phone on the beach 😂",
    lastMessageTime: '2:14 PM',
    relationship: 'Best friend',
  },
  {
    id: '2',
    name: 'Priya',
    avatar: 'P',
    lastMessage: "You always knew exactly what to say 💙",
    lastMessageTime: 'Yesterday',
    unread: 0,
    relationship: 'College roommate',
  },
  {
    id: '3',
    name: 'Arjun',
    avatar: 'A',
    lastMessage: "Man, those all-nighters before exams were something else",
    lastMessageTime: 'Mon',
    relationship: 'Childhood friend',
  },
  {
    id: '4',
    name: 'Meera',
    avatar: 'M',
    lastMessage: "That coffee place near your old apartment was the best",
    lastMessageTime: 'Sun',
    relationship: 'Ex-colleague',
  },
]

export const mockMessages: Message[] = [
  {
    id: '1',
    role: 'ai',
    content: "Hey! Didn't expect to hear from you like this. It's… strange but also kind of nice? 😅",
    timestamp: new Date(Date.now() - 1000 * 60 * 8),
  },
  {
    id: '2',
    role: 'user',
    content: "Do you remember that Goa trip?",
    timestamp: new Date(Date.now() - 1000 * 60 * 7),
  },
  {
    id: '3',
    role: 'ai',
    content: "How could I forget?! You almost lost your phone on the beach 😂 And then you made me retrace the entire stretch at 11pm with a torch. Classic you.",
    timestamp: new Date(Date.now() - 1000 * 60 * 6),
  },
  {
    id: '4',
    role: 'user',
    content: "That sunset on day two though. We stayed there for like two hours.",
    timestamp: new Date(Date.now() - 1000 * 60 * 5),
  },
  {
    id: '5',
    role: 'ai',
    content: "Yeah. We didn't even talk much, just sat there. Some of those silences were better than most conversations I've had. You brought those terrible chips and we finished the whole bag.",
    timestamp: new Date(Date.now() - 1000 * 60 * 4),
  },
  {
    id: '6',
    role: 'user',
    content: "I miss those days man. Everything felt simpler.",
    timestamp: new Date(Date.now() - 1000 * 60 * 3),
  },
  {
    id: '7',
    role: 'ai',
    content: "It did. But hey — you're doing more now than you give yourself credit for. You were always the one who figured it out, eventually. Sometimes just a bit dramatically 😄",
    timestamp: new Date(Date.now() - 1000 * 60 * 2),
  },
]
