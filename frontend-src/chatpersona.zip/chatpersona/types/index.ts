export type MessageRole = 'user' | 'ai';

export interface Message {
  id: string;
  role: MessageRole;
  content: string;
  timestamp: Date;
}

export interface Persona {
  id: string;
  name: string;
  initials: string;
  avatarColor: string;
  lastMessage: string;
  lastSeen: string;
  messageCount: number;
}

export type UploadState = 'idle' | 'uploading' | 'processing' | 'done';
