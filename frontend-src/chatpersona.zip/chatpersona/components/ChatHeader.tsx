'use client';
import { Persona } from '@/types';

interface ChatHeaderProps {
  persona: Persona;
  isTyping: boolean;
  onMenuToggle: () => void;
}

export default function ChatHeader({ persona, isTyping, onMenuToggle }: ChatHeaderProps) {
  return (
    <div
      className="flex items-center gap-3 px-5 py-4 border-b border-[var(--border-subtle)]"
      style={{ background: 'rgba(9,15,29,0.85)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)' }}
    >
      {/* Mobile menu */}
      <button
        onClick={onMenuToggle}
        className="lg:hidden w-8 h-8 flex items-center justify-center rounded-lg hover:bg-white/[0.06] transition-colors"
      >
        <svg className="w-4.5 h-4.5 text-[var(--text-secondary)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>

      {/* Avatar */}
      <div className="relative flex-shrink-0">
        <div
          className="w-10 h-10 rounded-2xl flex items-center justify-center text-white font-semibold text-sm"
          style={{ background: `linear-gradient(135deg, ${persona.avatarColor}ee, ${persona.avatarColor}88)`, boxShadow: `0 0 16px ${persona.avatarColor}30` }}
        >
          {persona.initials}
        </div>
        <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-sage-500 border-2 border-[#090f1d]" />
      </div>

      {/* Name & status */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h2 className="font-display text-base font-semibold text-[var(--text-primary)] truncate">{persona.name}</h2>
          <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-sage-600/10 text-sage-400 border border-sage-600/20 flex-shrink-0 hidden sm:block">
            AI Persona
          </span>
        </div>
        <div className="flex items-center gap-1.5 mt-0.5">
          {isTyping ? (
            <div className="flex items-center gap-1">
              <div className="flex items-center gap-0.5">
                {[0,1,2].map(i => (
                  <div
                    key={i}
                    className="w-1 h-1 rounded-full bg-sage-400"
                    style={{ animation: `bounceDot 1.2s ease-in-out ${i * 0.2}s infinite` }}
                  />
                ))}
              </div>
              <span className="text-xs text-sage-400">typing...</span>
            </div>
          ) : (
            <p className="text-xs text-[var(--text-muted)]">Based on your chat history · {persona.messageCount.toLocaleString()} messages</p>
          )}
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1 flex-shrink-0">
        <button className="w-8 h-8 rounded-xl flex items-center justify-center hover:bg-white/[0.06] transition-colors group">
          <svg className="w-4 h-4 text-[var(--text-muted)] group-hover:text-[var(--text-secondary)] transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </button>
        <button className="w-8 h-8 rounded-xl flex items-center justify-center hover:bg-white/[0.06] transition-colors group">
          <svg className="w-4 h-4 text-[var(--text-muted)] group-hover:text-[var(--text-secondary)] transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
          </svg>
        </button>
      </div>
    </div>
  );
}
