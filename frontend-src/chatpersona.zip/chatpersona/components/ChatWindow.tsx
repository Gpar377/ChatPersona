'use client';
import { Message, Persona } from '@/types';
import { useEffect, useRef } from 'react';
import MessageBubble from './MessageBubble';
import TypingIndicator from './TypingIndicator';

interface ChatWindowProps {
  messages: Message[];
  isTyping: boolean;
  persona: Persona;
}

function groupMessages(messages: Message[]) {
  const groups: { date: string; messages: Message[] }[] = [];
  messages.forEach(msg => {
    const dateStr = msg.timestamp.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
    const last = groups[groups.length - 1];
    if (last && last.date === dateStr) last.messages.push(msg);
    else groups.push({ date: dateStr, messages: [msg] });
  });
  return groups;
}

export default function ChatWindow({ messages, isTyping, persona }: ChatWindowProps) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const groups = groupMessages(messages);

  return (
    <div className="flex-1 overflow-y-auto px-4 sm:px-6 py-6 space-y-1">
      {/* Empty state */}
      {messages.length === 0 && (
        <div className="flex flex-col items-center justify-center h-full gap-4 text-center py-20 animate-fade-in">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center text-white text-xl font-semibold mb-2"
            style={{ background: `linear-gradient(135deg, ${persona.avatarColor}ee, ${persona.avatarColor}66)`, boxShadow: `0 0 32px ${persona.avatarColor}30` }}
          >
            {persona.initials}
          </div>
          <div>
            <h3 className="font-display text-xl text-[var(--text-primary)] mb-1">{persona.name} is here</h3>
            <p className="text-sm text-[var(--text-secondary)] max-w-xs">This persona was built from {persona.messageCount.toLocaleString()} real messages. Start a conversation.</p>
          </div>
          <div className="flex gap-2 flex-wrap justify-center mt-2">
            {["Remember that trip?", "What are you up to?", "Miss talking to you"].map(s => (
              <span key={s} className="text-xs px-3 py-1.5 rounded-full border border-[var(--border-medium)] text-[var(--text-muted)] hover:text-[var(--text-secondary)] hover:border-[var(--border-medium)] transition-colors cursor-default">
                {s}
              </span>
            ))}
          </div>
        </div>
      )}

      {groups.map(group => (
        <div key={group.date} className="space-y-2">
          {/* Date separator */}
          <div className="flex items-center gap-3 py-3">
            <div className="flex-1 h-px bg-[var(--border-subtle)]" />
            <span className="text-[10px] text-[var(--text-muted)] px-2 uppercase tracking-widest flex-shrink-0">{group.date}</span>
            <div className="flex-1 h-px bg-[var(--border-subtle)]" />
          </div>

          <div className="space-y-1.5">
            {group.messages.map((msg, idx) => (
              <MessageBubble
                key={msg.id}
                message={msg}
                personaName={persona.name}
                personaColor={persona.avatarColor}
                personaInitials={persona.initials}
                isLast={idx === 0 || group.messages[idx - 1].role !== msg.role}
              />
            ))}
          </div>
        </div>
      ))}

      {isTyping && (
        <div className="pt-1">
          <TypingIndicator />
        </div>
      )}
      <div ref={bottomRef} />
    </div>
  );
}
