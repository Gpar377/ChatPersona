'use client';
import { useState, useRef, KeyboardEvent, useEffect } from 'react';

interface InputBoxProps {
  onSend: (text: string) => void;
  isTyping: boolean;
  personaName: string;
}

export default function InputBox({ onSend, isTyping, personaName }: InputBoxProps) {
  const [value, setValue] = useState('');
  const [focused, setFocused] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  }, [value]);

  const handleSend = () => {
    const trimmed = value.trim();
    if (!trimmed || isTyping) return;
    onSend(trimmed);
    setValue('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const canSend = value.trim().length > 0 && !isTyping;

  return (
    <div
      className="px-4 sm:px-6 py-4 border-t border-[var(--border-subtle)]"
      style={{ background: 'rgba(9,15,29,0.9)', backdropFilter: 'blur(20px)', WebkitBackdropFilter: 'blur(20px)' }}
    >
      <div
        className={`flex items-end gap-3 rounded-2xl transition-all duration-300 px-4 py-3 ${
          focused
            ? 'ring-1 ring-sage-500/40 shadow-[0_0_20px_rgba(93,181,132,0.08)]'
            : ''
        }`}
        style={{
          background: focused ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.04)',
          border: `1px solid ${focused ? 'rgba(93,181,132,0.3)' : 'rgba(255,255,255,0.08)'}`,
          transition: 'all 0.25s ease',
        }}
      >
        {/* Emoji button */}
        <button className="flex-shrink-0 w-7 h-7 flex items-center justify-center rounded-lg hover:bg-white/[0.06] transition-colors mb-0.5 opacity-50 hover:opacity-100">
          <svg className="w-4 h-4 text-[var(--text-secondary)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </button>

        {/* Textarea */}
        <textarea
          ref={textareaRef}
          value={value}
          onChange={e => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          disabled={isTyping}
          placeholder={isTyping ? `${personaName} is typing...` : `Message ${personaName}...`}
          rows={1}
          className="flex-1 bg-transparent text-sm text-[var(--text-primary)] placeholder:text-[var(--text-muted)] resize-none outline-none leading-relaxed disabled:opacity-40"
          style={{ maxHeight: '120px' }}
        />

        {/* Send button */}
        <button
          onClick={handleSend}
          disabled={!canSend}
          className={`flex-shrink-0 w-8 h-8 rounded-xl flex items-center justify-center transition-all duration-200 mb-0.5 ${
            canSend
              ? 'bg-gradient-to-br from-sage-500 to-sage-600 hover:scale-110 hover:shadow-[0_4px_16px_rgba(93,181,132,0.4)] active:scale-95'
              : 'bg-[var(--border-subtle)] opacity-40 cursor-not-allowed'
          }`}
        >
          <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
          </svg>
        </button>
      </div>
      <p className="text-center text-[10px] text-[var(--text-muted)] mt-2 opacity-50">
        ChatPersona uses AI to simulate based on historical messages · Not a real person
      </p>
    </div>
  );
}
