'use client';

export default function TypingIndicator() {
  return (
    <div className="flex items-end gap-2.5 animate-fade-up">
      <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-sage-500/80 to-sage-600/60 flex items-center justify-center text-xs text-white font-semibold flex-shrink-0">
        R
      </div>
      <div
        className="px-4 py-3 rounded-2xl rounded-bl-md"
        style={{
          background: 'rgba(255,255,255,0.05)',
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
          border: '1px solid rgba(255,255,255,0.07)',
          boxShadow: '0 2px 12px rgba(0,0,0,0.2)',
        }}
      >
        <div className="flex items-center gap-1.5 h-4">
          {[0, 1, 2].map(i => (
            <div
              key={i}
              className="w-1.5 h-1.5 rounded-full bg-[var(--text-muted)]"
              style={{ animation: `bounceDot 1.2s ease-in-out ${i * 0.2}s infinite` }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
