'use client';
import { Persona } from '@/types';
import FileUpload from './FileUpload';

interface SidebarProps {
  personas: Persona[];
  currentPersonaId: string;
  onSelectPersona: (p: Persona) => void;
  onNewPersona: () => void;
  isOpen: boolean;
}

export default function Sidebar({ personas, currentPersonaId, onSelectPersona, onNewPersona, isOpen }: SidebarProps) {
  return (
    <>
      {/* Mobile overlay */}
      <div
        className={`fixed inset-0 bg-black/50 backdrop-blur-sm z-20 lg:hidden transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      />

      <aside className={`
        fixed top-0 left-0 h-full w-72 z-30 flex flex-col
        transition-transform duration-300 ease-out
        lg:relative lg:translate-x-0 lg:z-auto
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `}
        style={{ background: 'rgba(9,15,29,0.97)', borderRight: '1px solid rgba(255,255,255,0.06)' }}
      >
        {/* Logo */}
        <div className="px-5 pt-6 pb-5 border-b border-[var(--border-subtle)]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-sage-500 to-sage-600 flex items-center justify-center glow-sage flex-shrink-0">
              <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
              </svg>
            </div>
            <div>
              <h1 className="text-sm font-display font-semibold text-[var(--text-primary)] tracking-wide">ChatPersona</h1>
              <p className="text-[10px] text-[var(--text-muted)] mt-0.5 tracking-wider uppercase">Talk to your memories</p>
            </div>
          </div>
        </div>

        {/* Upload Section */}
        <div className="px-4 pt-5 pb-4 border-b border-[var(--border-subtle)]">
          <div className="flex items-center gap-1.5 mb-1">
            <svg className="w-3 h-3 text-[var(--text-muted)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
            <span className="text-[10px] font-medium text-[var(--text-muted)] uppercase tracking-widest">Import Chat</span>
          </div>
          <FileUpload onFileProcessed={(name) => {
            console.log('Processed:', name);
          }} />
        </div>

        {/* Persona List */}
        <div className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          <div className="flex items-center gap-1.5 px-2 mb-3">
            <svg className="w-3 h-3 text-[var(--text-muted)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
            <span className="text-[10px] font-medium text-[var(--text-muted)] uppercase tracking-widest">Your Personas</span>
          </div>

          {personas.map((persona, i) => (
            <button
              key={persona.id}
              onClick={() => onSelectPersona(persona)}
              className={`w-full text-left px-3 py-2.5 rounded-xl group relative transition-all duration-200 cursor-pointer
                ${currentPersonaId === persona.id
                  ? 'bg-sage-600/12 border border-sage-600/25'
                  : 'hover:bg-white/[0.04] border border-transparent hover:border-[var(--border-subtle)]'
                }`}
              style={{ animationDelay: `${i * 60}ms` }}
            >
              {currentPersonaId === persona.id && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-sage-500 rounded-full" />
              )}
              <div className="flex items-center gap-3">
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center text-white text-sm font-semibold flex-shrink-0"
                  style={{ background: `linear-gradient(135deg, ${persona.avatarColor}cc, ${persona.avatarColor}88)` }}
                >
                  {persona.initials}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-[var(--text-primary)] truncate">{persona.name}</p>
                    <span className="text-[10px] text-[var(--text-muted)] flex-shrink-0 ml-1">{persona.lastSeen}</span>
                  </div>
                  <p className="text-xs text-[var(--text-secondary)] truncate mt-0.5 opacity-70">{persona.lastMessage}</p>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* New Persona */}
        <div className="px-4 py-4 border-t border-[var(--border-subtle)]">
          <button
            onClick={onNewPersona}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl border border-dashed border-[var(--border-medium)] text-[var(--text-secondary)] text-sm hover:border-sage-600/50 hover:text-sage-400 hover:bg-sage-600/5 transition-all duration-200 group"
          >
            <svg className="w-4 h-4 group-hover:rotate-90 transition-transform duration-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            <span className="text-xs font-medium">New Persona</span>
          </button>
        </div>
      </aside>
    </>
  );
}
