'use client';
import { useState, useRef, DragEvent, ChangeEvent } from 'react';
import { UploadState } from '@/types';

interface FileUploadProps {
  onFileProcessed: (fileName: string) => void;
}

export default function FileUpload({ onFileProcessed }: FileUploadProps) {
  const [uploadState, setUploadState] = useState<UploadState>('idle');
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState('');
  const [progress, setProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const simulateUpload = (name: string) => {
    setFileName(name);
    setUploadState('uploading');
    setProgress(0);
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          setUploadState('processing');
          setTimeout(() => {
            setUploadState('done');
            onFileProcessed(name);
          }, 1800);
          return 100;
        }
        return p + Math.random() * 18;
      });
    }, 120);
  };

  const handleFile = (file: File) => {
    if (file.name.endsWith('.txt')) simulateUpload(file.name);
  };

  const onDrop = (e: DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const onFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  if (uploadState === 'done') {
    return (
      <div className="mt-3 px-3 py-2.5 rounded-xl bg-sage-600/10 border border-sage-600/20 flex items-center gap-2.5 animate-fade-in">
        <div className="w-7 h-7 rounded-lg bg-sage-600/20 flex items-center justify-center flex-shrink-0">
          <svg className="w-3.5 h-3.5 text-sage-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
          </svg>
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-xs font-medium text-sage-400 truncate">{fileName}</p>
          <p className="text-[10px] text-[var(--text-muted)] mt-0.5">Memory loaded ✦</p>
        </div>
      </div>
    );
  }

  if (uploadState === 'uploading' || uploadState === 'processing') {
    return (
      <div className="mt-3 px-3 py-3 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-card)]">
        <div className="flex items-center gap-2 mb-2">
          <div className="w-5 h-5 flex-shrink-0">
            {uploadState === 'processing' ? (
              <div className="w-5 h-5 rounded-full border-2 border-sage-500 border-t-transparent animate-spin" />
            ) : (
              <svg className="w-5 h-5 text-[var(--text-secondary)]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            )}
          </div>
          <span className="text-xs text-[var(--text-secondary)] truncate flex-1">{fileName}</span>
        </div>
        {uploadState === 'uploading' ? (
          <div className="h-1 w-full bg-[var(--border-subtle)] rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-sage-600 to-sage-400 rounded-full transition-all duration-150"
              style={{ width: `${Math.min(progress, 100)}%` }}
            />
          </div>
        ) : (
          <p className="text-[10px] text-sage-400 animate-pulse-soft">Building personality model...</p>
        )}
      </div>
    );
  }

  return (
    <div
      className={`mt-3 relative rounded-xl border-2 border-dashed cursor-pointer transition-all duration-300 ${
        isDragging
          ? 'border-sage-500 bg-sage-600/10 scale-[0.99]'
          : 'border-[var(--border-medium)] hover:border-sage-600/50 hover:bg-white/[0.02]'
      }`}
      onDragOver={e => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={onDrop}
      onClick={() => fileInputRef.current?.click()}
    >
      <input ref={fileInputRef} type="file" accept=".txt" className="hidden" onChange={onFileChange} />
      <div className="py-4 px-3 flex flex-col items-center gap-1.5 text-center">
        <div className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-300 ${isDragging ? 'bg-sage-600/20' : 'bg-[var(--border-subtle)]'}`}>
          <svg className={`w-4 h-4 transition-colors ${isDragging ? 'text-sage-400' : 'text-[var(--text-muted)]'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
          </svg>
        </div>
        <p className="text-xs font-medium text-[var(--text-secondary)]">Drop your WhatsApp chat</p>
        <p className="text-[10px] text-[var(--text-muted)]">.txt export · drag or click</p>
      </div>
    </div>
  );
}
