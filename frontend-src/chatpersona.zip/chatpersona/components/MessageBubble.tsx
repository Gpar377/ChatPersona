'use client';
import { Message } from '@/types';
import { useEffect, useState } from 'react';

interface MessageBubbleProps {
  message: Message;
  personaName: string;
  personaColor: string;
  personaInitials: string;
  isLast: boolean;
}

function formatTime(date: Date): string {
  return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
}

export default function MessageBubble({ message, personaName, personaColor, personaInitials, isLast }: MessageBubbleProps) {
  const [visible, setVisible] = useState(false);
  const isUser = message.role === 'user';

  useEffect(() => {
    const t = setTimeout(() => setVisible(true), 30);
    return () => clearTimeout(t);
  }, []);

  return (
    <div
      className={`flex gap-2.5 transition-all duration-400 ${isUser ? 'justify-end' : 'justify-start'} ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'}`}
      style={{ transition: 'opacity 0.35s ease, transform 0.35s ease' }}
    >
      {/* AI Avatar */}
      {!isUser && (
        <div className="flex-shrink-0 self-end mb-1">
          <div
            className="w-7 h-7 rounded-xl flex items-center justify-center text-white text-xs font-semibold"
            style={{ background: `linear-gradient(135deg, ${personaColor}dd, ${personaColor}88)` }}
          >
            {personaInitials}
          </div>
        </div>
      )}

      {/* Bubble */}
      <div className={`max-w-[72%] sm:max-w-[60%] flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
        {!isUser && isLast && (
          <span className="text-[10px] text-[var(--text-muted)] mb-1 ml-1">{personaName}</span>
        )}
        <div
          className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed relative ${
            isUser
              ? 'text-white rounded-br-md'
              : 'text-[var(--text-primary)] rounded-bl-md border border-[var(--border-subtle)]'
          }`}
          style={isUser ? {
            background: 'linear-gradient(135deg, #3d9e68, #5db584)',
            boxShadow: '0 2px 12px rgba(61,158,104,0.25), 0 1px 3px rgba(0,0,0,0.3)',
          } : {
            background: 'rgba(255,255,255,0.05)',
            backdropFilter: 'blur(12px)',
            WebkitBackdropFilter: 'blur(12px)',
            boxShadow: '0 2px 12px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.05)',
          }}
        >
          {message.content}
          {/* Subtle sheen on user bubble */}
          {isUser && (
            <div className="absolute inset-0 rounded-2xl rounded-br-md overflow-hidden pointer-events-none">
              <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent" />
            </div>
          )}
        </div>
        <span className={`text-[10px] text-[var(--text-muted)] mt-1 ${isUser ? 'mr-1' : 'ml-1'}`}>
          {formatTime(message.timestamp)}
          {isUser && <span className="ml-1 text-sage-400">✓✓</span>}
        </span>
      </div>

      {/* User avatar */}
      {isUser && (
        <div className="flex-shrink-0 self-end mb-1">
          <div className="w-7 h-7 rounded-xl bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center text-xs font-semibold text-[var(--text-secondary)]">
            U
          </div>
        </div>
      )}
    </div>
  );
}
