import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'ChatPersona — Talk to your memories',
  description: 'Simulate conversations with people from your past using AI.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
