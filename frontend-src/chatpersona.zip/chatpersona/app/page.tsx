'use client';
import { useState, useCallback } from 'react';
import Sidebar from '@/components/Sidebar';
import ChatHeader from '@/components/ChatHeader';
import ChatWindow from '@/components/ChatWindow';
import InputBox from '@/components/InputBox';
import { Message, Persona } from '@/types';
import { mockPersonas, mockMessages, aiResponses } from '@/lib/mockData';

export default function Home() {
  const [personas] = useState<Persona[]>(mockPersonas);
  const [currentPersona, setCurrentPersona] = useState<Persona>(mockPersonas[0]);
  const [messages, setMessages] = useState<Message[]>(mockMessages);
  const [isTyping, setIsTyping] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleSend = useCallback((text: string) => {
    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date(),
    };
    setMessages(prev => [...prev, userMsg]);
    setIsTyping(true);

    const delay = 1200 + Math.random() * 1400;
    setTimeout(() => {
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'ai',
        content: aiResponses[Math.floor(Math.random() * aiResponses.length)],
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
    }, delay);
  }, []);

  const handleSelectPersona = (p: Persona) => {
    setCurrentPersona(p);
    setMessages([]);
    setSidebarOpen(false);
    setTimeout(() => setMessages(mockMessages), 50);
  };

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: 'var(--bg-base)' }}>
      {/* Background atmosphere */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div
          className="absolute -top-40 -left-40 w-80 h-80 rounded-full opacity-20"
          style={{ background: 'radial-gradient(circle, rgba(93,181,132,0.15) 0%, transparent 70%)', filter: 'blur(60px)' }}
        />
        <div
          className="absolute bottom-20 right-20 w-60 h-60 rounded-full opacity-10"
          style={{ background: 'radial-gradient(circle, rgba(126,200,160,0.2) 0%, transparent 70%)', filter: 'blur(80px)' }}
        />
      </div>

      <Sidebar
        personas={personas}
        currentPersonaId={currentPersona.id}
        onSelectPersona={handleSelectPersona}
        onNewPersona={() => setSidebarOpen(false)}
        isOpen={sidebarOpen}
      />

      {/* Main chat area */}
      <main className="flex-1 flex flex-col min-w-0 relative">
        <ChatHeader
          persona={currentPersona}
          isTyping={isTyping}
          onMenuToggle={() => setSidebarOpen(o => !o)}
        />
        <ChatWindow
          messages={messages}
          isTyping={isTyping}
          persona={currentPersona}
        />
        <InputBox
          onSend={handleSend}
          isTyping={isTyping}
          personaName={currentPersona.name}
        />
      </main>
    </div>
  );
}
