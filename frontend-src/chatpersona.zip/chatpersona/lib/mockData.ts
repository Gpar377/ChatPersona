import { Message, Persona } from '@/types';

export const mockPersonas: Persona[] = [
  {
    id: '1',
    name: 'Rahul',
    initials: 'R',
    avatarColor: '#5db584',
    lastMessage: 'How could I forget? 😂',
    lastSeen: '2 days ago',
    messageCount: 847,
  },
  {
    id: '2',
    name: 'Priya',
    initials: 'P',
    avatarColor: '#e8845a',
    lastMessage: 'Miss those chai sessions...',
    lastSeen: '5 days ago',
    messageCount: 1203,
  },
  {
    id: '3',
    name: 'Arjun',
    initials: 'A',
    avatarColor: '#7b8de8',
    lastMessage: 'Dude that was so funny 💀',
    lastSeen: '1 week ago',
    messageCount: 562,
  },
];

export const mockMessages: Message[] = [
  {
    id: '1',
    role: 'ai',
    content: "Hey! It's been a while. What's on your mind? 😊",
    timestamp: new Date(Date.now() - 1000 * 60 * 10),
  },
  {
    id: '2',
    role: 'user',
    content: 'Do you remember that Goa trip?',
    timestamp: new Date(Date.now() - 1000 * 60 * 9),
  },
  {
    id: '3',
    role: 'ai',
    content: "How could I forget?? You almost lost your phone on the beach 😂 And then we spent like an hour retracing our steps in the dark. Classic.",
    timestamp: new Date(Date.now() - 1000 * 60 * 8),
  },
  {
    id: '4',
    role: 'user',
    content: "Haha yes! And you were so calm about it while I was panicking.",
    timestamp: new Date(Date.now() - 1000 * 60 * 7),
  },
  {
    id: '5',
    role: 'ai',
    content: "Someone had to be! But honestly I was lowkey stressed too lol. That was such a good trip though. The sunset from that rooftop café... man.",
    timestamp: new Date(Date.now() - 1000 * 60 * 6),
  },
];

export const aiResponses = [
  "Honestly, that takes me back. I remember exactly how that felt.",
  "You always had this way of making things more fun than they needed to be 😄",
  "I've thought about that too, more than I'd admit.",
  "That's such a you thing to say. I missed hearing that.",
  "Wait, do you still have those photos? Because I've been looking for them forever.",
  "Lol stop, you're making me nostalgic now 😭",
  "Some things don't change. This conversation feels like no time has passed.",
  "Tell me more — I want to hear your version of how that happened.",
];
