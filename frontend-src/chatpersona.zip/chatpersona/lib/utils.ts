export function formatTime(date: Date): string {
  return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true })
}

export function generateId(): string {
  return Math.random().toString(36).substring(2, 9)
}

export function getAIResponse(input: string, responses: Record<string, string[]>): string {
  const lower = input.toLowerCase()
  
  if (lower.includes('goa') || lower.includes('trip') || lower.includes('beach')) {
    const arr = responses.goa
    return arr[Math.floor(Math.random() * arr.length)]
  }
  if (lower.includes('miss') || lower.includes('remember')) {
    const arr = responses.miss
    return arr[Math.floor(Math.random() * arr.length)]
  }
  if (lower.includes('food') || lower.includes('eat') || lower.includes('hungry')) {
    const arr = responses.food
    return arr[Math.floor(Math.random() * arr.length)]
  }
  
  const arr = responses.default
  return arr[Math.floor(Math.random() * arr.length)]
}
